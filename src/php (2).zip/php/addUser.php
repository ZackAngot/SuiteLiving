<div class="pb-5 container">
    <div class="row">
        <div class=" col-xl-9 mx-auto">
            <div class="cta-inner text-center rounded">
                <h2 class="section-heading mb-5">
                    <span class="section-heading-upper">Admin Page</span>
                    <span class="section-heading-lower">Add User</span>
                </h2>
                <div class="card-body">
                    <form id = "addUser" action="" onsubmit=" return checkformAddUser()">
                        <div class="form-group">
                            <label class="mb-1" for="inputUserID">UserID</label>
                            <input type="text" class="form-control py-4" id="inputUserID" placeholder="UserID">
                            <div id="userID_error" class ="error"></div>
                        </div>
                        <div class="justify-content-lg-between form-row" id="addAnnouncementDate">
                            <div class="form-group col-md-6">
                                <label class="mb-1" for="inputPassword">Password</label>
                                <input type="password" class="form-control py-4" id="inputPassword" placeholder="Password">
                                <div id="inputPassword_error" class ="error"></div>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="mb-1" for="confirmPassword">Confirm Password</label>
                                <input type="password" class="form-control py-4" id="confirmPassword" placeholder="Confirmed Password">
                                <div id="confirmPassword_error" class ="error"></div>
                            </div>
                        </div>

                        <div class="p-2" id = "checkUserDiv">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="A">
                                <label class="form-check-label" for="inlineRadio1">Admin User</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="M">
                                <label class="form-check-label" for="inlineRadio2">Maintenance User</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="R">
                                <label class="form-check-label" for="inlineRadio3">Room User</label>
                            </div>
                            <div id="radio_error" class ="error"></div>
                        </div>
                        <div id = "NameDiv">
                            <div class="form-group">
                                <label class="mb-1" for="firstName">First Name</label>
                                <input type="text" class="form-control py-4" id="firstName" placeholder="First Name">
                                <div id="fname_error" class ="error"></div>
                            </div>
                            <div class="form-group">
                                <label class="mb-1" for="lastName">Last Name</label>
                                <input type="text" class="form-control py-4" id="lastName" placeholder="Last Name">
                                <div id="lname_error" class ="error"></div>
                            </div>
                        </div>
                        <div class="form-group d-flex align-items-center justify-content-between mt-4 mb-0">
                            <input class="btn btn-danger btn-xlonclick" type="reset" value="Reset">
                            <button id="submitAdduser" type="submit" class="btn btn-primary btn-xlonclick">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>