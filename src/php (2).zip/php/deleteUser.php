<div class="p-5 mx-auto">
    <div class="mb-4 shadow-lg bg-faded rounded">
        <h2 class="bg-primary card-header section-heading text-center mb-5">
            <span class="fas fa-table mr-1"></span>
            <span class=" section-heading-lower">Delete Staff Users</span>
        </h2>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-borderless" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr class = "bg-primary">
                        <th>Staff ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Staff Type</th>
                        <th>Remove User</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr class = "bg-primary">
                        <th>Staff ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Staff Type</th>
                        <th>Remove User</th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php
                    $output ="";
                    $staffData = grabData("SELECT * FROM staff");
                    foreach ($staffData as $Data) {
                        $output= "
                                                <tr id = ".json_encode($Data['StaffID']).">
                                                <td>Staff ID: ".$Data['StaffID']."</td>
                                                <td>First Name: ".$Data['FirstName']."</td>
                                                <td>Last Name: ".$Data['LastName']."</td>
                                                <td>Staff Type: ".$Data['StaffType']."</td>
                                                <td><p onclick = 'removeStaff(".json_encode($Data['StaffID']). ")' class ='btn btn-primary btn-xlonclick'>Remove User</p></td>";

                        $output.="</tr>";
                        echo $output;
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="p-5 mx-auto">
    <div class="mb-4 shadow-lg bg-faded rounded">
        <h2 class="bg-primary card-header section-heading text-center mb-5">
            <span class="fas fa-table mr-1"></span>
            <span class=" section-heading-lower">Remove Room Log In</span>
        </h2>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-borderless" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr class = "bg-primary">
                        <th>Staff ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Remove Room Log in</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr class = "bg-primary">
                        <th>Staff ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Remove Room Log in</th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php
                    $output ="";
                    $staffData = grabData("SELECT * FROM userlogin WHERE UserType = 'R'");
                    foreach ($staffData as $Data) {
                        $output= "
                                                <tr id = ".json_encode($Data['UserID']).">
                                                <td>User ID: ".$Data['UserID']."</td>
                                                <td>User Password: ".$Data['Password']."</td>
                                                <td>User Type: ".$Data['UserType']."</td>
                                                   <td><p onclick = 'removeRoom(".json_encode($Data['UserID']).")' class ='btn btn-primary btn-xlonclick'>Remove User</p></td>";
                        $output.="</tr>";
                        echo $output;
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>